/* content.js — Smart.pr Labs: Angle Assistant (MV3)
 * - Injects a "Generate angles" button next to Smart.pr "Create content"
 * - Mirrors disabled state of the native Create content button
 * - Modal with Subject (prefilled), optional Short description
 * - Generate concise angles (1-sentence perspectives)
 * - Press release generator from any generated angle
 * - Uses chrome.storage.sync for OpenAI key (set in options page)
 */

// ---------- Utilities ----------
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

function deepQuerySelectorAll(selector, roots = [document]) {
  const results = new Set();
  const queue = [...roots];
  const visited = new Set();

  while (queue.length) {
    const root = queue.shift();
    if (!root || visited.has(root)) continue;
    visited.add(root);

    if (typeof root.querySelectorAll === 'function') {
      let matches = [];
      try { matches = root.querySelectorAll(selector); } catch { matches = []; }
      matches.forEach(el => results.add(el));
      let frames = [];
      try { frames = root.querySelectorAll('iframe'); } catch { frames = []; }
      frames.forEach(frame => {
        try {
          const doc = frame.contentDocument || frame.contentWindow?.document;
          if (doc) queue.push(doc);
        } catch {
          // Ignore cross-origin frames.
        }
      });

      let elements = [];
      try { elements = root.querySelectorAll('*'); } catch { elements = []; }
      elements.forEach(el => {
        if (el.shadowRoot) queue.push(el.shadowRoot);
      });
    }
  }

  return Array.from(results);
}

const storage = {
  get: (k, d = null) => new Promise(r => chrome.storage.sync.get([k], v => r(v[k] ?? d))),
  set: (k, v) => new Promise(r => chrome.storage.sync.set({ [k]: v }, r)),
};

const localStore = {
  get: (k, d = null) => new Promise(r => chrome.storage.local.get([k], v => r(v[k] ?? d))),
  set: (k, v) => new Promise(r => chrome.storage.local.set({ [k]: v }, r)),
};

const FEATURE_KEYS = {
  angleAssistant: 'feature_angle_assistant',
  prFeedback: 'feature_pr_feedback',
};

const DEFAULT_FEATURE_FLAGS = {
  angleAssistant: true,
  prFeedback: true,
};

let featureFlags = { ...DEFAULT_FEATURE_FLAGS };
let featuresReady = false;

const normalizeFeatureValue = (value, fallback = true) => (typeof value === 'boolean' ? value : fallback);

function loadFeatureFlags() {
  return new Promise(resolve => {
    chrome.storage.sync.get(Object.values(FEATURE_KEYS), stored => {
      featureFlags = {
        angleAssistant: normalizeFeatureValue(stored[FEATURE_KEYS.angleAssistant], DEFAULT_FEATURE_FLAGS.angleAssistant),
        prFeedback: normalizeFeatureValue(stored[FEATURE_KEYS.prFeedback], DEFAULT_FEATURE_FLAGS.prFeedback),
      };
      featuresReady = true;
      resolve(featureFlags);
    });
  });
}

function applyFeatureUpdates(partialFlags = {}) {
  let changed = false;
  const next = { ...featureFlags };
  for (const key of Object.keys(partialFlags)) {
    if (key in next && partialFlags[key] !== undefined && next[key] !== partialFlags[key]) {
      next[key] = partialFlags[key];
      changed = true;
    }
  }
  if (!changed) return;
  featureFlags = next;
  if (!featureFlags.angleAssistant) teardownAngleAssistant();
  if (!featureFlags.prFeedback) teardownPRFeedback();
  runInjections();
}

const USAGE_KEY = 'sase_usage';

async function recordUsage(usage = {}) {
  try {
    const current = await localStore.get(USAGE_KEY, {
      requests: 0,
      promptTokens: 0,
      completionTokens: 0,
      totalTokens: 0,
      lastUpdated: 0,
    });
    const next = {
      requests: (current.requests || 0) + 1,
      promptTokens: (current.promptTokens || 0) + (usage.prompt_tokens || 0),
      completionTokens: (current.completionTokens || 0) + (usage.completion_tokens || 0),
      totalTokens: (current.totalTokens || 0) + (usage.total_tokens || ((usage.prompt_tokens || 0) + (usage.completion_tokens || 0))),
      lastUpdated: Date.now(),
    };
    await localStore.set(USAGE_KEY, next);
  } catch (err) {
    console.debug('[Smartpr Labs] Failed to record usage', err);
  }
}

function escapeHTML(s) {
  return (s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function escapeAttr(s) {
  return escapeHTML(s).replace(/\n/g, ' ');
}
function safeParseJSON(str) {
  try { return JSON.parse(str); } catch { return null; }
}
async function copyToClipboard(text) {
  try { await navigator.clipboard.writeText(text); }
  catch {
    const ta = document.createElement('textarea');
    ta.value = text; document.body.appendChild(ta); ta.select();
    document.execCommand('copy'); ta.remove();
  }
}
function toast(msg) {
  const el = document.createElement('div');
  el.textContent = msg;
  Object.assign(el.style, {
    position: 'fixed', left: '50%', bottom: '28px', transform: 'translateX(-50%)',
    background: '#0f2c36', color: '#e7f3f7', padding: '10px 14px', borderRadius: '10px',
    border: '1px solid #2a5563', zIndex: 1000000,
    font: '13px/1.2 system-ui, -apple-system, Segoe UI, Roboto, Arial'
  });
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 1800);
}

function getSubjectField() {
  // Common selectors for the Subject input on the Smart.pr form
  return $('input[placeholder="Please type your subject"], input[name="subject"], input[aria-label="Subject"]');
}

function getSenderField() {
  return $('input[name="sender__label"], input[name="sender_label"], input[aria-label="Sender"], input[placeholder="Search sender..."]');
}

// ---------- API key handling ----------
async function getApiKey() {
  const key = await storage.get('sase_api', '');
  if (!key) {
    if (confirm('OpenAI API key not set. Open extension settings now?')) {
      chrome.runtime.sendMessage({ action: 'openOverviewPage' });
    }
    throw new Error('Missing API key');
  }
  return key;
}

// ---------- OpenAI call ----------
async function openAIChat(apiKey, systemPrompt, userPrompt, temperature = 0.8) {
  const resp = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      temperature
    })
  });
  if (!resp.ok) {
    const err = await resp.text();
    throw new Error(`OpenAI error: ${resp.status} ${err}`);
  }
  const data = await resp.json();
  recordUsage(data?.usage || {}).catch(() => {});
  return data.choices?.[0]?.message?.content ?? '';
}

const PR_FEEDBACK_SYSTEM_PROMPT = `
Act as a **senior PR editor and email deliverability coach**.
You receive raw HTML of a press-release mailing.

Your job: deliver clear, concise editorial feedback that helps the sender make their mailing more professional, engaging, and correct.

### Review checklist
1. Strip all HTML and read only the text.
2. Detect the dominant language (Dutch or English) and respond **entirely in that language**, including all headings.
3. Evaluate:
   - Clarity and structure
   - Tone and storytelling
   - Grammar, spelling, and punctuation (list specific typos if any)
   - Readability and sentence flow
   - Call-to-action clarity **(ignore standard unsubscribe links added automatically by email software)**

### Write your response in plain text with the following three sections, using headings in the same language as the text:
**Sterktes** (if Dutch) / **Strengths** (if English)  
Summarize 3–5 clear positives (e.g. human quotes, news angle, tone, flow).

**Verbeterpunten** (if Dutch) / **Areas for improvement** (if English)  
Point out concrete issues — including grammar or spelling errors — and explain briefly why they matter.

**Aanpak** (if Dutch) / **Action plan** (if English)  
List practical next steps or short rewrite examples showing how to fix the problems. Use bullet points or short paragraphs, not code blocks or Markdown symbols.

### Style guidelines
- Be professional, pragmatic, and concise.
- Avoid Markdown syntax like #, ####, or triple backticks.
- Never restate the whole text; focus only on insights.
- Do not include raw HTML.
`;




const BRIDGE_SCRIPT_ID = 'spr-pr-feedback-bridge';
const BRIDGE_REQUEST = 'SPR_FEEDBACK_GET_HTML';
const BRIDGE_RESPONSE = 'SPR_FEEDBACK_HTML';
const BRIDGE_READY = 'SPR_FEEDBACK_BRIDGE_READY';
const BRIDGE_PING = 'SPR_FEEDBACK_BRIDGE_PING';

let bridgeReady = false;
let bridgeReadyWaiters = [];
const bridgeHtmlRequests = new Map();
let lastFeedbackInput = '';
let inputModal = null;

function logFeedback(...args) {
  try {
    console.debug('[Smartpr Labs][Feedback]', ...args);
  } catch {
    // ignore logging errors
  }
}

function markdownToHtml(md) {
  if (!md) return '';
  const escaped = escapeHTML(md);
  const withLists = escaped.replace(/(^|\n)(- .+(?:\n- .+)*)/g, (match, prefix, listBlock) => {
    const items = listBlock.trim().split('\n')
      .map(line => line.replace(/^- /, '').trim())
      .filter(Boolean)
      .map(item => `<li>${item}</li>`)
      .join('');
    return `${prefix}<ul>${items}</ul>`;
  });

  let html = withLists
    .replace(/^### (.*)$/gm, '<h3>$1</h3>')
    .replace(/^## (.*)$/gm, '<h2>$1</h2>')
    .replace(/^# (.*)$/gm, '<h1>$1</h1>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>');

  html = html.replace(/(?:\r?\n){2,}/g, '</p><p>');
  html = html.replace(/(?:\r?\n)/g, '<br>');
  html = `<p>${html}</p>`;
  html = html.replace(/<p>(\s*<ul>)/g, '$1').replace(/(<\/ul>)\s*<\/p>/g, '$1');
  html = html.replace(/<p>(\s*<h[1-6]>)/g, '$1').replace(/(<\/h[1-6]>)\s*<\/p>/g, '$1');
  return html;
}

function ensureFeedbackInputModal() {
  if (inputModal && document.body.contains(inputModal)) return inputModal;
  const modal = document.createElement('div');
  modal.id = 'spr-feedback-input-modal';
  modal.innerHTML = `
    <div class="spr-feedback-input-card">
      <div class="spr-feedback-input-header">
        <strong>Input sent to ChatGPT</strong>
        <button type="button" class="spr-feedback-action" data-feedback-input-close title="Close">✕</button>
      </div>
      <textarea readonly class="spr-feedback-input-text"></textarea>
    </div>
  `;
  document.body.appendChild(modal);
  const closeBtn = modal.querySelector('[data-feedback-input-close]');
  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      modal.style.display = 'none';
    });
  }
  inputModal = modal;
  return modal;
}

function showFeedbackInputModal() {
  if (!lastFeedbackInput) {
    toast('No input captured yet.');
    return;
  }
  const modal = ensureFeedbackInputModal();
  const textarea = modal.querySelector('.spr-feedback-input-text');
  if (textarea) {
    textarea.value = lastFeedbackInput;
    textarea.scrollTop = 0;
  }
  modal.style.display = 'flex';
}

function handleBridgeMessage(event) {
  if (event.source !== window || !event.data || typeof event.data !== 'object') return;
  const { type, html, id } = event.data;
  if (type === BRIDGE_READY) {
    bridgeReady = true;
    const waiters = bridgeReadyWaiters.slice();
    bridgeReadyWaiters = [];
    waiters.forEach(fn => { try { fn(); } catch { /* ignore */ } });
    logFeedback('Bridge reported ready');
  } else if (type === BRIDGE_RESPONSE && id) {
    const pending = bridgeHtmlRequests.get(id);
    if (!pending) return;
    bridgeHtmlRequests.delete(id);
    clearTimeout(pending.timeout);
    pending.resolve(typeof html === 'string' ? html.trim() : '');
    logFeedback('Received HTML from bridge', { id, length: html ? html.length : 0 });
  }
}

if (!window.__sprFeedbackBridgeListenerAttached) {
  window.addEventListener('message', handleBridgeMessage, false);
  window.__sprFeedbackBridgeListenerAttached = true;
}

function injectBeeBridge() {
  if (document.getElementById(BRIDGE_SCRIPT_ID)) return;
  const script = document.createElement('script');
  script.id = BRIDGE_SCRIPT_ID;
  script.src = chrome.runtime.getURL('page-bridge.js');
  script.async = false;
  script.onload = () => {
    setTimeout(() => {
      if (script.parentNode) script.parentNode.removeChild(script);
    }, 0);
  };
  (document.head || document.documentElement).appendChild(script);
  logFeedback('Injected page bridge');
}

function waitForBridgeReady(timeout = 6000) {
  if (bridgeReady) return Promise.resolve(true);
  injectBeeBridge();
  return new Promise(resolve => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      bridgeReadyWaiters = bridgeReadyWaiters.filter(fn => fn !== onReady);
      logFeedback('Bridge ready wait timed out after', timeout, 'ms');
      resolve(false);
    }, timeout);
    const onReady = () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      bridgeReadyWaiters = bridgeReadyWaiters.filter(fn => fn !== onReady);
      logFeedback('Bridge ready wait resolved');
      resolve(true);
    };
    bridgeReadyWaiters.push(onReady);
    try { window.postMessage({ type: BRIDGE_PING }, '*'); } catch { /* ignore */ }
  });
}

async function requestBeeHtmlViaBridge(timeout = 6000) {
  injectBeeBridge();
  await waitForBridgeReady(6000);

  const id = `spr-${Date.now().toString(36)}-${Math.random().toString(16).slice(2)}`;
  return new Promise(resolve => {
    const timer = setTimeout(() => {
      bridgeHtmlRequests.delete(id);
      logFeedback('Bridge request timed out', { id, timeout });
      resolve('');
    }, timeout);
    bridgeHtmlRequests.set(id, { resolve, timeout: timer });
    try {
      window.postMessage({ type: BRIDGE_REQUEST, id }, '*');
      logFeedback('Requested HTML from bridge', { id });
    } catch {
      clearTimeout(timer);
      bridgeHtmlRequests.delete(id);
      logFeedback('Failed to post request to bridge', { id });
      resolve('');
    }
  });
}

// ---------- Modal UI ----------
function ensureModal() {
  if ($('#sase-modal')) return;

  const wrap = document.createElement('div');
  wrap.id = 'sase-modal';
  wrap.innerHTML = `
    <div class="sase-card">
      <div class="sase-row">
        <strong>Smart.pr Labs — Angle Assistant</strong>
        <button class="sase-btn secondary" id="sase-settings" title="Open settings">⚙️</button>
        <button class="sase-close" title="Close" id="sase-close">✕</button>
      </div>

      <div class="sase-row">
        <input id="sase-subject" type="text" placeholder="Subject line (prefilled from the form)" />
      </div>

      <div class="sase-row">
        <input id="sase-sender" type="text" placeholder="Sender (prefilled from the form)" />
      </div>

      <div class="sase-row">
        <textarea id="sase-desc" rows="3" placeholder="Optional: short description / context (e.g., what’s new, data points, launch details)"></textarea>
      </div>

      <div class="sase-row">
        <button id="sase-gen-angles" class="sase-btn">✨ Generate angles</button>
        <button id="sase-clear" class="sase-btn secondary">Clear</button>
      </div>

      <div class="sase-row sase-small">
        Angles are one-sentence perspectives you can take on the story. Use any of them to draft a press release.
      </div>

      <div class="sase-row"><strong>Angles</strong></div>
      <div id="sase-angles" class="sase-list"></div>
    </div>
  `;
  document.body.appendChild(wrap);

  // Wire controls
  $('#sase-close').onclick = () => $('#sase-modal').style.display = 'none';
  $('#sase-clear').onclick = () => { $('#sase-angles').innerHTML = ''; };
  $('#sase-settings').onclick = () => chrome.runtime.sendMessage({ action: 'openOverviewPage' });
  $('#sase-gen-angles').onclick = onGenerateAngles;
}

function setBusy(btnId, busy) {
  const btn = $(btnId);
  if (!btn) return;
  btn.disabled = busy;
  const orig = btn.dataset.label || btn.textContent;
  if (!btn.dataset.label) btn.dataset.label = orig;
  btn.textContent = busy ? 'Working…' : btn.dataset.label;
}

// ---------- Generators ----------
async function onGenerateAngles() {
  const subject = $('#sase-subject').value.trim();
  const desc = $('#sase-desc').value.trim();
  if (!subject) return toast('Please enter a subject.');

  let key; try { key = await getApiKey(); } catch { return; }

  const sys = `You are a senior PR strategist. Produce concise, one-sentence "angles" (perspectives) on the topic.
Return JSON only: {"angles":[ "…", "…", ... ]} with 1–5 items (never more than five). Each item <= 30 words, crisp, distinct.
Determine the dominant language of the subject line and write every angle in that language. Do not translate into English unless the subject itself is in English.`;
  const user = `Subject line: ${subject}
${desc ? `Short description: ${desc}` : ''}
All output must stay in the same language as the subject line.`;

  setBusy('#sase-gen-angles', true);
  try {
    const json = await openAIChat(key, sys, user, 0.7);
    const parsed = safeParseJSON(json);
    renderAngles(parsed?.angles || []);
  } catch (e) {
    console.error('[SASE] angles error', e);
    toast('Error generating angles.');
  } finally {
    setBusy('#sase-gen-angles', false);
  }
}

// ---------- Renderers ----------
function renderAngles(angles) {
  const box = $('#sase-angles');
  box.innerHTML = '';
  const trimmed = (angles || []).map(a => typeof a === 'string' ? a.trim() : '').filter(Boolean).slice(0, 5);
  if (!trimmed.length) {
    box.innerHTML = '<div class="sase-small">No angles generated.</div>';
    return;
  }

  trimmed.forEach((angle, idx) => {
    const div = document.createElement('div');
    div.className = 'sase-item';
    div.innerHTML = `
      <h4>Angle #${idx + 1}</h4>
      <div class="sase-small">${escapeHTML(angle)}</div>

      <div class="sase-actions" style="margin-top:8px">
        <button class="sase-btn" data-copy-angle="${escapeAttr(angle)}">Copy angle</button>
        <button class="sase-btn secondary" data-pressrelease-angle="${escapeAttr(angle)}">Write press release</button>
        <button class="sase-btn secondary" data-copy-pr style="display:none">Copy press release</button>
      </div>

      <pre class="sase-mono sase-small" style="white-space:pre-wrap; display:none"></pre>
    `;
    box.appendChild(div);

    div.querySelector('[data-copy-angle]').onclick = async (e) => {
      await copyToClipboard(e.target.getAttribute('data-copy-angle'));
      toast('Angle copied.');
    };

    div.querySelector('[data-pressrelease-angle]').onclick = async (e) => {
      const ang = e.target.getAttribute('data-pressrelease-angle');
      await writePressReleaseFromAngle(div, ang);
    };

    const copyPrBtn = div.querySelector('[data-copy-pr]');
    if (copyPrBtn) {
      copyPrBtn.onclick = async () => {
        const pre = div.querySelector('pre');
        if (!pre?.textContent?.trim()) return toast('No press release yet.');
        await copyToClipboard(pre.textContent);
        toast('Press release copied.');
      };
    }
  });
}

// ---------- Press release writers ----------
async function writePressReleaseFromAngle(container, angle) {
  let key; try { key = await getApiKey(); } catch { return; }
  const subject = $('#sase-subject').value.trim();
  const desc = $('#sase-desc').value.trim();
  const sender = $('#sase-sender')?.value.trim();

  const sys = `You are a PR copywriter. Based on the provided one-sentence angle and context, craft a compelling press release with your own strong headline.
Length ≈300–350 words. 
Structure:
- Headline (you create)
- Dek (1 sentence)
- City, Date —
- Body with two quotes (one CEO/founder, one external expert)
- Boilerplate
- Media contact (use the provided sender details verbatim when available; otherwise create a brief placeholder)
Tone: clear, factual, newsworthy. Avoid fluff.
Determine the dominant language of the provided angle or subject and write the entire press release in that language. Only default to English if the language cannot be determined.`;
  const user = `Angle: ${angle}
Subject line: ${subject}
${desc ? `Context: ${desc}` : ''}
${sender ? `Sender contact (use verbatim for the Media contact line): ${sender}` : 'Sender contact: Not provided; create a short placeholder.'}
Language requirement: Match the language used in the angle/subject.`;

  try {
    setPressReleaseBusy(container, true);
    const text = await openAIChat(key, sys, user, 0.7);
    showPR(container, text);
  } catch (e) {
    console.error('[SASE] PR from angle error', e);
    toast('Error writing press release.');
    resetPressRelease(container);
  } finally {
    setPressReleaseBusy(container, false);
  }
}

function showPR(container, text) {
  const pre = container.querySelector('pre');
  pre.textContent = text.trim();
  pre.style.display = 'block';
  const actionRow = container.querySelector('.sase-actions');
  const copyBtn = actionRow?.querySelector('[data-copy-pr]');
  if (copyBtn) {
    copyBtn.style.display = '';
    copyBtn.disabled = false;
  }
}

function setPressReleaseBusy(container, busy) {
  const btn = container.querySelector('[data-pressrelease-angle]');
  if (!btn) return;
  const copyBtn = container.querySelector('[data-copy-pr]');
  const pre = container.querySelector('pre');
  if (busy) {
    if (!btn.dataset.label) btn.dataset.label = btn.textContent;
    btn.textContent = 'Generating…';
    btn.disabled = true;
    if (copyBtn) {
      copyBtn.style.display = 'none';
      copyBtn.disabled = true;
    }
    if (pre) {
      pre.textContent = 'Generating press release…';
      pre.style.display = 'block';
    }
  } else {
    btn.disabled = false;
    if (btn.dataset.label) btn.textContent = btn.dataset.label;
  }
}

function resetPressRelease(container) {
  const pre = container.querySelector('pre');
  if (pre) {
    pre.textContent = '';
    pre.style.display = 'none';
  }
  const copyBtn = container.querySelector('[data-copy-pr]');
  if (copyBtn) {
    copyBtn.style.display = 'none';
    copyBtn.disabled = false;
  }
}

// ---------- Button injection & state mirroring ----------
let mirrorInterval = null;

function ensureInjected() {
  if (!featureFlags.angleAssistant) return;
  // Match your Angular markup
  const candidates = $$('button.form-mailing-edit__button, button[ng-click="onDesignClick();"]');
  const createBtn = candidates.find(b => (b.textContent || '').trim().toLowerCase() === 'create content');
  if (!createBtn) return;

  // Avoid duplicate injection
  if (!createBtn.dataset.saseInjected) {
    const genBtn = document.createElement('button');
    genBtn.type = 'button';
    genBtn.className = 'form-mailing-edit__button ui-button__root ui-button__root--default ui-button__root--big sase-generate-btn';
    genBtn.textContent = '✨ Generate angles';
    createBtn.insertAdjacentElement('afterend', genBtn);
    createBtn.dataset.saseInjected = '1';

    // Build modal once
    ensureModal();

    // Open modal + prefill Subject from the real field
    genBtn.addEventListener('click', () => {
      const subjField = getSubjectField();
      const modalSubj = $('#sase-subject');
      if (modalSubj) modalSubj.value = subjField && subjField.value ? subjField.value.trim() : '';
      const senderField = getSenderField();
      const modalSender = $('#sase-sender');
      if (modalSender) modalSender.value = senderField && senderField.value ? senderField.value.trim() : '';
      $('#sase-modal').style.display = 'flex';
    });
  }

  // Mirror disabled state onto our button
  const ourBtn = createBtn.nextElementSibling && createBtn.nextElementSibling.classList.contains('sase-generate-btn')
    ? createBtn.nextElementSibling
    : null;
  if (!ourBtn) return;

  const mirror = () => {
    const isDisabled = createBtn.hasAttribute('disabled') || createBtn.disabled || createBtn.classList.contains('ui-button__root--disabled');
    ourBtn.disabled = !!isDisabled;
    // Optional: style parity (grey out)
    if (isDisabled) {
      ourBtn.style.opacity = '0.6';
      ourBtn.style.pointerEvents = 'none';
    } else {
      ourBtn.style.opacity = '';
      ourBtn.style.pointerEvents = '';
    }
  };
  mirror();

  // Watch attribute changes to keep in sync
  const attrObs = new MutationObserver(mirror);
  attrObs.observe(createBtn, { attributes: true, attributeFilter: ['disabled', 'class', 'aria-disabled'] });
  if (createBtn._saseObserver) {
    try { createBtn._saseObserver.disconnect(); } catch { /* ignore */ }
  }
  createBtn._saseObserver = attrObs;

  // Also poll lightly in case Angular swaps the node
  if (mirrorInterval) clearInterval(mirrorInterval);
  mirrorInterval = setInterval(() => {
    if (!document.body.contains(createBtn)) {
      clearInterval(mirrorInterval);
      return;
    }
    mirror();
  }, 800);
}

function teardownAngleAssistant() {
  if (mirrorInterval) {
    clearInterval(mirrorInterval);
    mirrorInterval = null;
  }
  $$('.sase-generate-btn').forEach(btn => btn.remove());
  const modal = $('#sase-modal');
  if (modal) modal.remove();
  $$('[data-sase-injected]').forEach(btn => {
    if (btn._saseObserver) {
      try { btn._saseObserver.disconnect(); } catch { /* ignore */ }
      delete btn._saseObserver;
    }
    btn.removeAttribute('data-sase-injected');
  });
}

// ---------- PR Feedback Assistant ----------
function ensurePRFeedbackPanel() {
  if (!document.body) return null;
  let panel = $('#spr-feedback-panel');
  if (panel) return panel;

  panel = document.createElement('div');
  panel.id = 'spr-feedback-panel';
  panel.innerHTML = `
    <div class="spr-feedback-header">
      <strong>PR Feedback</strong>
      <button type="button" class="spr-feedback-action" data-feedback-view-input style="display:none">View input</button>
      <button type="button" class="spr-feedback-action" data-feedback-copy style="display:none">Copy</button>
      <button type="button" class="spr-feedback-close" data-feedback-close title="Close">✕</button>
    </div>
    <div id="spr-feedback-status" class="spr-feedback-status"></div>
    <div id="spr-feedback-content" class="spr-feedback-content"></div>
  `;
  document.body.appendChild(panel);

  const closeBtn = panel.querySelector('[data-feedback-close]');
  if (closeBtn) closeBtn.addEventListener('click', hideFeedbackPanel);

  const copyBtn = panel.querySelector('[data-feedback-copy]');
  if (copyBtn) {
    copyBtn.addEventListener('click', async () => {
      const contentEl = panel.querySelector('#spr-feedback-content');
      const content = contentEl?.dataset?.raw ?? contentEl?.textContent ?? '';
      if (!content.trim()) {
        toast('Nothing to copy yet.');
        return;
      }
      await copyToClipboard(content);
      toast('Feedback copied.');
    });
  }

  const viewInputBtn = panel.querySelector('[data-feedback-view-input]');
  if (viewInputBtn) {
    viewInputBtn.addEventListener('click', () => showFeedbackInputModal());
  }

  return panel;
}

function showFeedbackPanel() {
  const panel = ensurePRFeedbackPanel();
  if (!panel) return null;
  panel.style.display = 'flex';
  return panel;
}

function hideFeedbackPanel() {
  const panel = $('#spr-feedback-panel');
  if (panel) panel.style.display = 'none';
}

function setFeedbackPanelState(state, message = '') {
  const panel = ensurePRFeedbackPanel();
  if (!panel) return;
  const statusEl = panel.querySelector('#spr-feedback-status');
  const contentEl = panel.querySelector('#spr-feedback-content');
  const copyBtn = panel.querySelector('[data-feedback-copy]');
  const viewInputBtn = panel.querySelector('[data-feedback-view-input]');
  if (!statusEl || !contentEl || !copyBtn) return;

  statusEl.classList.remove('is-error');
  if (state === 'loading') {
    statusEl.textContent = message || 'Loading…';
    statusEl.style.display = '';
    contentEl.textContent = '';
    contentEl.dataset.raw = '';
   copyBtn.style.display = 'none';
   if (viewInputBtn) viewInputBtn.style.display = lastFeedbackInput ? '' : 'none';
 } else if (state === 'error') {
    statusEl.textContent = message || 'Something went wrong.';
    statusEl.style.display = '';
    statusEl.classList.add('is-error');
    contentEl.textContent = '';
    contentEl.dataset.raw = '';
   copyBtn.style.display = 'none';
   if (viewInputBtn) viewInputBtn.style.display = lastFeedbackInput ? '' : 'none';
 } else if (state === 'success') {
    statusEl.textContent = '';
    statusEl.style.display = 'none';
    contentEl.dataset.raw = message;
    contentEl.innerHTML = markdownToHtml(message);
   copyBtn.style.display = '';
   if (viewInputBtn) viewInputBtn.style.display = lastFeedbackInput ? '' : 'none';
 }
}

async function requestPRFeedback() {
  showFeedbackPanel();
  setFeedbackPanelState('loading', 'Collecting mailing content…');
  logFeedback('Feedback request started');

  const mailingHTML = await collectMailingHTML();
  if (!mailingHTML) {
    setFeedbackPanelState('error', 'Could not find the mailing content on this page.');
    logFeedback('No mailing HTML available');
    return;
  }
  logFeedback('Mailing HTML collected', { length: mailingHTML.length });
  lastFeedbackInput = mailingHTML;
  const viewBtn = $('#spr-feedback-panel [data-feedback-view-input]');
  if (viewBtn) viewBtn.style.display = lastFeedbackInput ? '' : 'none';

  let apiKey;
  try {
    apiKey = await getApiKey();
  } catch {
    setFeedbackPanelState('error', 'Add your OpenAI API key via the extension options to request feedback.');
    logFeedback('API key missing');
    return;
  }

  const userPrompt = `Here is the HTML of the mailing currently being edited in Smart.pr:\n\n${mailingHTML}`;

  try {
    setFeedbackPanelState('loading', 'Requesting PR feedback…');
    logFeedback('Calling OpenAI for feedback');
    const feedback = await openAIChat(apiKey, PR_FEEDBACK_SYSTEM_PROMPT, userPrompt, 0.4);
    setFeedbackPanelState('success', feedback.trim());
    logFeedback('Received feedback from OpenAI', { length: feedback ? feedback.length : 0 });
  } catch (err) {
    console.error('[SASE] PR feedback error', err);
    setFeedbackPanelState('error', 'Could not fetch PR feedback. Please try again.');
    logFeedback('OpenAI request failed', err?.message || err);
  }
}

async function collectMailingHTML() {
  const PRIMARY_SELECTOR = '.publisher-mailing-html__root';
  const secondarySelectors = [
    '.publisher-mailings-design-bee__body',
    '[mailing-id-selector="publisherMailingIdSelector"]',
    '.mailing-html__iframe',
    'publisher-mailing-html',
    'div.stageContent',
    'div.Stage_stageInner__M9-ST',
    'div.Stage_stageInner',
    'div.stageInner',
    '.stageInner',
    '.Stage_stageInner__M9-ST'
  ];

  const beeHtml = await requestBeeHtmlViaBridge();
  if (beeHtml) {
    logFeedback('Using HTML from bridge', { length: beeHtml.length });
    return beeHtml;
  }
  logFeedback('Bridge did not return HTML, falling back to DOM scraping');

  const primaryNodes = deepQuerySelectorAll(PRIMARY_SELECTOR).filter(Boolean);
  if (primaryNodes.length) {
    const htmlChunks = primaryNodes
      .map(node => (node.outerHTML || '').trim())
      .filter(Boolean);
    if (htmlChunks.length) {
      logFeedback('Collected HTML via primary selectors', { nodes: htmlChunks.length });
      return htmlChunks.join('\n\n');
    }
  }

  for (const selector of secondarySelectors) {
    const candidates = deepQuerySelectorAll(selector).filter(Boolean);
    if (candidates.length) {
      const htmlChunks = candidates
        .map(node => (node.outerHTML || '').trim())
        .filter(Boolean);
      if (htmlChunks.length) {
        logFeedback('Collected HTML via secondary selector', { selector, nodes: htmlChunks.length });
        return htmlChunks.join('\n\n');
      }
    }
  }

  logFeedback('Failed to collect mailing HTML');
  return '';
}

function ensurePRFeedbackButton() {
  if (!featureFlags.prFeedback) return;
  const buttons = $$('button.ui-button__root, button.publisher-mailings-design-bee__button');
  const saveBtn = buttons.find(btn => (btn.textContent || '').trim().toLowerCase() === 'save as template');
  if (!saveBtn || saveBtn.dataset.sprFeedbackAttached) return;
  logFeedback('Injecting PR Feedback button');

  const askBtn = document.createElement('button');
  askBtn.type = 'button';
  askBtn.className = 'publisher-mailings-design-bee__button ui-button__root ui-button__root--default ui-button__root--big spr-feedback-btn';
  askBtn.textContent = '✨ Ask feedback';
  askBtn.dataset.sprFeedbackBtn = '1';
  saveBtn.insertAdjacentElement('beforebegin', askBtn);
  saveBtn.dataset.sprFeedbackAttached = '1';

  askBtn.addEventListener('click', requestPRFeedback);

  const mirror = () => {
    const disabled = saveBtn.disabled
      || saveBtn.classList.contains('ui-button__root--disabled')
      || saveBtn.hasAttribute('disabled')
      || saveBtn.getAttribute('aria-disabled') === 'true';
    askBtn.disabled = !!disabled;
    askBtn.style.opacity = disabled ? '0.6' : '';
    askBtn.style.pointerEvents = disabled ? 'none' : '';
  };
  mirror();

  const observer = new MutationObserver(mirror);
  observer.observe(saveBtn, { attributes: true, attributeFilter: ['disabled', 'class', 'aria-disabled'] });
  askBtn._sprFeedbackObserver = observer;
}

function teardownPRFeedback() {
  const panel = $('#spr-feedback-panel');
  if (panel) panel.remove();
  $$('.spr-feedback-btn').forEach(btn => {
    if (btn._sprFeedbackObserver) {
      try { btn._sprFeedbackObserver.disconnect(); } catch { /* ignore */ }
      delete btn._sprFeedbackObserver;
    }
    btn.remove();
  });
  $$('[data-spr-feedback-attached]').forEach(btn => {
    btn.removeAttribute('data-spr-feedback-attached');
  });
  hideFeedbackPanel();
}

// Initial injection & observe SPA updates
function runInjections() {
  if (!featuresReady) return;

  if (featureFlags.angleAssistant) {
    ensureInjected();
  } else {
    teardownAngleAssistant();
  }

  if (featureFlags.prFeedback) {
    ensurePRFeedbackButton();
    logFeedback('Ran injection pass');
  } else {
    teardownPRFeedback();
  }
}

let injectionObserver = null;

async function initFeatures() {
  await loadFeatureFlags();
  runInjections();
  if (!injectionObserver) {
    injectionObserver = new MutationObserver(runInjections);
    injectionObserver.observe(document.documentElement, { childList: true, subtree: true });
  }
}

initFeatures();

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'sync') return;
  const updates = {};
  if (FEATURE_KEYS.angleAssistant in changes) {
    updates.angleAssistant = normalizeFeatureValue(changes[FEATURE_KEYS.angleAssistant].newValue, DEFAULT_FEATURE_FLAGS.angleAssistant);
  }
  if (FEATURE_KEYS.prFeedback in changes) {
    updates.prFeedback = normalizeFeatureValue(changes[FEATURE_KEYS.prFeedback].newValue, DEFAULT_FEATURE_FLAGS.prFeedback);
  }
  applyFeatureUpdates(updates);
});

// Prefill modal subject whenever subject input changes
(function watchSubjectField() {
  const subj = getSubjectField();
  if (!subj) return;
  subj.addEventListener('input', () => {
    const modalSubj = $('#sase-subject');
    if (modalSubj && $('#sase-modal')?.style.display !== 'none') {
      modalSubj.value = subj.value;
    }
  });
})();

(function watchSenderField() {
  const sender = getSenderField();
  if (!sender) return;
  sender.addEventListener('input', () => {
    const modalSender = $('#sase-sender');
    if (modalSender && $('#sase-modal')?.style.display !== 'none') {
      modalSender.value = sender.value;
    }
  });
})();
